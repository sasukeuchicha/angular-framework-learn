package com.maveric.usercreation.entities;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.Set;

@Table
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private long userId;
    @Column(unique = true, nullable = false)
    @NotBlank
    @Size(min=4, max=25, message = "The username should be of size minimum 4 to 25 characters long")
    private String username;
    @Column(nullable = false)
    @NotBlank
    private String password;
    @ElementCollection(fetch= FetchType.EAGER)
    private Set<String> roles;

}
