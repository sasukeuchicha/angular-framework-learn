package com.maveric.usercreation.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Prospect {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long prospectId;
    private boolean customerId;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private User user;
    @Size(min = 1, max = 50, message = "Provide valid first name")
    private String firstName;
    @Size(min=1, max = 30, message = "Provide valid last name")
    private String lastName;
    @Pattern(regexp = "^(\\+\\d{1,3})?[-.\\s]?\\d{10,}$", message = "Invalid phone number")
    private String mobileNumber;
    private String optionalDetails;
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Prospect prospect = (Prospect) o;
        return Objects.equals(prospectId, prospect.prospectId);
    }
    @Override
    public int hashCode() {
        return Objects.hash(prospectId);
    }
}
