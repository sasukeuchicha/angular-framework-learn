package com.maveric.usercreation.dao;

import com.maveric.usercreation.entities.Prospect;
import com.maveric.usercreation.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IProspectRepository extends JpaRepository<Prospect, Long> {
    Optional<Prospect> findByUser(User user);
}
