package com.maveric.usercreation.dao;

import com.maveric.usercreation.entities.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IAdminRepository extends JpaRepository<Admin,Long> {
}
