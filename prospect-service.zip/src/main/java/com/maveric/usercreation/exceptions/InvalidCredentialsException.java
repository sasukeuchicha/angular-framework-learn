package com.maveric.usercreation.exceptions;

public class InvalidCredentialsException extends Exception{
    public InvalidCredentialsException(String msg){super(msg);}
}
