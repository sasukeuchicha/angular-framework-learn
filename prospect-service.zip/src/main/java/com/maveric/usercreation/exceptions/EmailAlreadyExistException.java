package com.maveric.usercreation.exceptions;

public class EmailAlreadyExistException extends Exception{
    public EmailAlreadyExistException(String msg){
        super(msg);
    }
}
