package com.maveric.usercreation.exceptions;

public class JWTTokenExpiredException extends Exception{
    public JWTTokenExpiredException(String message){super(message);}
}
