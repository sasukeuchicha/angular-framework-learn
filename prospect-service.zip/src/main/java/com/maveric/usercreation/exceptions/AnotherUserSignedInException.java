package com.maveric.usercreation.exceptions;

public class AnotherUserSignedInException extends Exception{
    public AnotherUserSignedInException(String msg){super(msg);}
}
