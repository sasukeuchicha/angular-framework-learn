package com.maveric.usercreation.exceptions;

public class ChangePasswordNotSameException extends Exception{
    public ChangePasswordNotSameException(String msg){super(msg);}
}
