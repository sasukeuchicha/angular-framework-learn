package com.maveric.usercreation.exceptions;

public class JWTAuthenticationException extends Exception{
    public JWTAuthenticationException(String msg){super(msg);}
}
