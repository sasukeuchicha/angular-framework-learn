package com.maveric.usercreation.exceptions;

public class ProspectIdNotFoundException extends Exception{
    public ProspectIdNotFoundException(String msg){super(msg);}
}
