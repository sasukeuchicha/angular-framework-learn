package com.maveric.usercreation.exceptions;

import com.maveric.usercreation.dtos.ErrorMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


@ControllerAdvice
@ResponseStatus
public class CentralizedExceptionHandler extends ResponseEntityExceptionHandler {
    @ExceptionHandler(AnotherUserSignedInException.class)
    public ResponseEntity<ErrorMessage> anotherUserSingedInException(AnotherUserSignedInException exception,
                                                                     WebRequest request){
        ErrorMessage message = new ErrorMessage(HttpStatus.BAD_REQUEST, exception.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }
    @ExceptionHandler(EmailAlreadyExistException.class)
    public ResponseEntity<ErrorMessage> emailAlreadyInUser(EmailAlreadyExistException exception,
                                                           WebRequest request){
        ErrorMessage message = new ErrorMessage(HttpStatus.NOT_ACCEPTABLE, exception.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(message);
    }
    @ExceptionHandler(EmailNotFoundException.class)
    public ResponseEntity<ErrorMessage> emailNotFound(EmailNotFoundException exception,
                                                           WebRequest request){
        ErrorMessage message = new ErrorMessage(HttpStatus.INTERNAL_SERVER_ERROR, exception.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(message);
    }

    @ExceptionHandler(ChangePasswordNotSameException.class)
    public ResponseEntity<ErrorMessage> changePasswordNotSame(ChangePasswordNotSameException exception,
                                                      WebRequest request){
        ErrorMessage message = new ErrorMessage(HttpStatus.BAD_REQUEST, exception.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }

    @ExceptionHandler(JWTAuthenticationException.class)
    public ResponseEntity<ErrorMessage> jwtTokenError(JWTAuthenticationException exception,
                                                      WebRequest request){
        ErrorMessage message = new ErrorMessage(HttpStatus.BAD_REQUEST, exception.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }
    @ExceptionHandler(JWTTokenExpiredException.class)
    public ResponseEntity<ErrorMessage> jwtTokenExpired(JWTTokenExpiredException exception,
                                                        WebRequest request){
        ErrorMessage message = new ErrorMessage(HttpStatus.UNAUTHORIZED, exception.getMessage());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(message);
    }
    @ExceptionHandler(ProspectIdNotFoundException.class)
    public ResponseEntity<ErrorMessage> prospectNotFound(ProspectIdNotFoundException exception,
                                                      WebRequest request){
        ErrorMessage message = new ErrorMessage(HttpStatus.NOT_FOUND, exception.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
    }
    @ExceptionHandler(InvalidCredentialsException.class)
    public ResponseEntity<ErrorMessage> invalidCredentialsException(InvalidCredentialsException exception,
                                                           WebRequest request){
        ErrorMessage message = new ErrorMessage(HttpStatus.BAD_REQUEST, exception.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
    }
}

