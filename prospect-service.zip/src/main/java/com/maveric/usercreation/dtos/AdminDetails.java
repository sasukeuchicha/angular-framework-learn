package com.maveric.usercreation.dtos;

import java.util.Set;

public class AdminDetails {
    private long adminId;
    private String username;
    private Set<String>roles;
    public Set<String> getRoles() {
        return roles;
    }
    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }
    public long getAdminId() {
        return adminId;
    }
    public void setAdminId(long adminId) {
        this.adminId = adminId;
    }
    public String getusername() {
        return username;
    }
    public void setusername(String username) {
        this.username = username;
    }
}
