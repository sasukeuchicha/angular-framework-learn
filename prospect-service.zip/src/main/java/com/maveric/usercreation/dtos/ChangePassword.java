package com.maveric.usercreation.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
@NonNull
public class ChangePassword {
    @NotBlank
    private String username;
    @NotBlank
    private String password;
    @NotBlank
    private String reconfirmPassword;
}
