package com.maveric.usercreation.dtos;

import lombok.Builder;
import lombok.Data;

import java.util.Set;

@Data
@Builder
public class ProspectDetails {
    private long prospectId;
    private String firstName;
    private String lastName;
    private String username;
    private String mobileNumber;
}
