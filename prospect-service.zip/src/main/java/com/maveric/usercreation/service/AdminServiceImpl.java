package com.maveric.usercreation.service;

import com.maveric.usercreation.entities.Admin;
import com.maveric.usercreation.entities.User;
import com.maveric.usercreation.dao.IAdminRepository;
import com.maveric.usercreation.dtos.AddAdmin;
import com.maveric.usercreation.dtos.AdminDetails;
import com.maveric.usercreation.util.AdminUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Set;


@Service
public class AdminServiceImpl implements IAdminService {
    private IAdminRepository repository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    private AdminUtil adminUtil;
    public AdminServiceImpl(IAdminRepository repository, AdminUtil adminUtil){
        this.repository=repository;
        this.adminUtil=adminUtil;
    }
    @Transactional
    @Override
    public AdminDetails register(AddAdmin requestData) {
        // Add admin
        Set<String> roles=new HashSet<>();
        roles.add("ADMIN");
        User user=User.builder()
                        .userId(1)
                        .username(requestData.getUsername())
                        .password(passwordEncoder.encode(requestData.getPassword()))
                        .roles(roles).build();
        Admin admin = Admin.builder()
                        .id(1)
                        .user(user)
                        .build();
        admin=repository.saveAndFlush(admin);
       return adminUtil.adminDetails(admin);
    }
}
