package com.maveric.usercreation.service;

import com.maveric.usercreation.dtos.AddProspect;
import com.maveric.usercreation.dtos.ChangePassword;
import com.maveric.usercreation.dtos.ProspectDetails;
import com.maveric.usercreation.exceptions.*;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;

@Validated
public interface IProspectService {

    ProspectDetails register(@Valid AddProspect requestData) throws AnotherUserSignedInException, EmailAlreadyExistException;
    ProspectDetails update(@Valid AddProspect requestData, String authHeader) throws ProspectIdNotFoundException, EmailNotFoundException, JWTAuthenticationException;
    ProspectDetails changePassword(@Valid ChangePassword requestData, String authHeader) throws ChangePasswordNotSameException, EmailNotFoundException, JWTAuthenticationException, ProspectIdNotFoundException;
    ProspectDetails findByUsername() throws EmailNotFoundException, ProspectIdNotFoundException;
    long getCurrentProspectId(String authHeader) throws EmailNotFoundException, JWTAuthenticationException, ProspectIdNotFoundException;
    ProspectDetails getProspectDetails(String authHeader) throws EmailNotFoundException, ProspectIdNotFoundException, JWTAuthenticationException;
}
