package com.maveric.usercreation.service;

import com.maveric.usercreation.config.security.JwtTokenHelper;
import com.maveric.usercreation.exceptions.InvalidCredentialsException;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Service
public class LogoutService implements LogoutHandler {
    @Autowired
    private JwtTokenHelper jwtTokenHelper;
    @Autowired
    private UserDetailsService userDetailsService;

    @SneakyThrows
    public void logout(HttpServletRequest request,
                       HttpServletResponse response,
                       Authentication authentication) {
        String authHeader = request.getHeader("Authorization");
        if(authHeader==null || !authHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException("User not signed in");
        }
        String username = jwtTokenHelper.getusernameFromToken(authHeader.substring(7));
        jwtTokenHelper.expireToken(this.userDetailsService.loadUserByUsername(username));
    }
}
