package com.maveric.usercreation.service;

import com.maveric.usercreation.config.security.JwtTokenHelper;
import com.maveric.usercreation.dao.IUserRepository;
import com.maveric.usercreation.dtos.ChangePassword;
import com.maveric.usercreation.entities.Prospect;
import com.maveric.usercreation.entities.User;
import com.maveric.usercreation.dao.IProspectRepository;
import com.maveric.usercreation.dtos.AddProspect;
import com.maveric.usercreation.dtos.ProspectDetails;
import com.maveric.usercreation.exceptions.*;
import com.maveric.usercreation.util.ProspectUtil;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class ProspectServiceImpl implements IProspectService {

    @Autowired
    private ProspectUtil prospectUtil;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private IProspectRepository prospectRepository;
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private JwtTokenHelper jwtTokenHelper;

    @Transactional

    public ProspectDetails register(AddProspect requestData) throws EmailAlreadyExistException {
        Set<String> roles=new HashSet<>();
        Prospect prospectSaved;
        roles.add("PROSPECT");
        User userCreated = User.builder()
                        .username(requestData.getUsername())
                        .password(passwordEncoder.encode(requestData.getPassword()))
                        .roles(roles)
                        .build();
        Prospect prospect = Prospect.builder()
                .user(userCreated)
                .firstName(requestData.getFirstName())
                .lastName(requestData.getLastName())
                .mobileNumber(requestData.getMobileNumber())
                .build();

        User userAlreadyExist = userRepository
                .findUserByusername(requestData.getUsername())
                .orElse(null);
        if(userAlreadyExist==null) {
            prospectSaved = prospectRepository.save(prospect);}
        else{
            throw new EmailAlreadyExistException("User Name already found");}
        return prospectUtil.prospectDetails(prospectSaved);
    }

    @Override
    public ProspectDetails update(AddProspect requestDto, String authHeader) throws ProspectIdNotFoundException, EmailNotFoundException, JWTAuthenticationException {
        ProspectDetails prospectDetails = this.getProspectDetails(authHeader);
        long currentProspectId = prospectDetails.getProspectId();
        Prospect currentProspect = prospectRepository
                .findById(currentProspectId)
                .orElseThrow(() -> new
                        ProspectIdNotFoundException("The user is not signed up yet and not found in database")
                );
        if(isNotBlank(requestDto.getFirstName())){
            currentProspect.setFirstName(requestDto.getFirstName());
        }
        if(isNotBlank(requestDto.getLastName())){
            currentProspect.setLastName(requestDto.getLastName());
        }
        if(isNotBlank(requestDto.getMobileNumber())){
            currentProspect.setMobileNumber(requestDto.getMobileNumber());
        }
        if(isNotBlank(requestDto.getPassword())){
            User userCreate = new User(currentProspect.getUser().getUserId(),
            currentProspect.getUser().getUsername(),
                    passwordEncoder.encode(requestDto.getPassword()),
                    currentProspect.getUser().getRoles()
            );
            currentProspect.setUser(userCreate);
        }
        Prospect prospectSaved = prospectRepository.save(currentProspect);
        return prospectUtil.prospectDetails(prospectSaved);
    }

    @Override
    public ProspectDetails changePassword(ChangePassword requestData, String authHeader) throws ChangePasswordNotSameException, EmailNotFoundException, JWTAuthenticationException, ProspectIdNotFoundException {
        if(!requestData.getPassword().equals(requestData.getReconfirmPassword())){
             throw new ChangePasswordNotSameException("Unable to change Password due to error. Recheck input");
        }
        ProspectDetails prospectDetails = this.getProspectDetails(authHeader);
        long currentProspectId = prospectDetails.getProspectId();
        Prospect currentProspect = prospectRepository
                .findById(currentProspectId)
                .orElseThrow(() -> new
                        ProspectIdNotFoundException("The user is not signed up yet and not found in database")
                );
        if(isNotBlank(requestData.getPassword())){
            User userCreate = new User(currentProspect.getUser().getUserId(),
                    currentProspect.getUser().getUsername(),
                    passwordEncoder.encode(requestData.getPassword()),
                    currentProspect.getUser().getRoles()
            );
            currentProspect.setUser(userCreate);
        }
        Prospect prospectSaved = prospectRepository.save(currentProspect);
        return prospectUtil.prospectDetails(prospectSaved);

    }


    @Override
    public ProspectDetails findByUsername() throws EmailNotFoundException, ProspectIdNotFoundException {
        Authentication currentUser = SecurityContextHolder.getContext().getAuthentication();
        String username = currentUser.getName();
        User userFound = userRepository.findUserByusername(username)
                .orElseThrow(() -> new EmailNotFoundException("Username not found"));
        Prospect prospectFound = prospectRepository.findByUser(userFound)
                .orElseThrow(() -> new ProspectIdNotFoundException("Database error"));
        return prospectUtil.prospectDetails(prospectFound);
    }

    @Override
    public ProspectDetails getProspectDetails(String authHeader) throws EmailNotFoundException, ProspectIdNotFoundException, JWTAuthenticationException {
        String token = this.validateTokenFromReceiver(authHeader);
        String username = jwtTokenHelper.getusernameFromToken(token);
        User userFound = userRepository.findUserByusername(username)
                .orElseThrow(() -> new EmailNotFoundException("Username not found"));
        Prospect prospectFound = prospectRepository.findByUser(userFound)
                .orElseThrow(() -> new ProspectIdNotFoundException("Database error"));
        return prospectUtil.prospectDetails(prospectFound);
    }


    private String validateTokenFromReceiver(String authHeader) throws JWTAuthenticationException {
        String[] headerParts = authHeader.split(" ");
        if (headerParts.length != 2 && !"Bearer".equals(headerParts[0])) {
            throw new JWTAuthenticationException("Error token provided. Please login once again");
        }
        String authToken =  headerParts[1].trim();
        boolean isTokenExpired = jwtTokenHelper.isTokenExpired(authToken);
        if (isTokenExpired){
            throw new JWTAuthenticationException("Token is expired. Login once again");
        }
        return authToken;
    }


    public long getCurrentProspectId(String authHeader) throws EmailNotFoundException, JWTAuthenticationException, ProspectIdNotFoundException {
        return this.getProspectDetails(authHeader).getProspectId();
    }
}
