package com.maveric.usercreation.service;

import com.maveric.usercreation.config.security.JwtAuthResponse;
import com.maveric.usercreation.config.security.JwtTokenHelper;
import com.maveric.usercreation.dtos.LoginRequest;
import com.maveric.usercreation.exceptions.InvalidCredentialsException;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

@Service
public class AppServiceImpl implements IAppService{
    @Autowired
    private JwtTokenHelper jwtTokenHelper;
    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private AuthenticationManager authentication;

    @Override
    public ResponseEntity<JwtAuthResponse> login(LoginRequest requestDto) throws InvalidCredentialsException {
        String username = requestDto.getUsername();
        String password = requestDto.getPassword();
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password);
        this.authentication.authenticate(authenticationToken);
        UserDetails userDetails;
        try {
            userDetails = this.userDetailsService.loadUserByUsername(username);
        } catch (BadCredentialsException exception) {
            throw new InvalidCredentialsException("Invalid Credentials. Check Username and password");
        }
        String token = this.jwtTokenHelper.generateToken(userDetails);
        JwtAuthResponse response = new JwtAuthResponse();
        response.setToken(token);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
