package com.maveric.usercreation.service;

import com.maveric.usercreation.dtos.AddAdmin;
import com.maveric.usercreation.dtos.AdminDetails;

public interface IAdminService {
    AdminDetails register(AddAdmin requestData);
}
