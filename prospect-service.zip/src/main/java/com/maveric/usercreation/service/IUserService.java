package com.maveric.usercreation.service;

import org.springframework.validation.annotation.Validated;

@Validated
public interface IUserService {
}
