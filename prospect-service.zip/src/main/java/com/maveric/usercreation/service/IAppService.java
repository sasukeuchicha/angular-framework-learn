package com.maveric.usercreation.service;

import com.maveric.usercreation.config.security.JwtAuthResponse;
import com.maveric.usercreation.dtos.LoginRequest;
import com.maveric.usercreation.exceptions.InvalidCredentialsException;
import org.springframework.http.ResponseEntity;

import javax.validation.Valid;

public interface IAppService{
    ResponseEntity<JwtAuthResponse> login(@Valid LoginRequest requestDto) throws InvalidCredentialsException;
}
