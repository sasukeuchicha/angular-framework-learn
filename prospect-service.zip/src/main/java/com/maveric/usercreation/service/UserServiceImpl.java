package com.maveric.usercreation.service;

import com.maveric.usercreation.entities.User;
import com.maveric.usercreation.dao.IUserRepository;
import com.maveric.usercreation.dtos.ProspectDetailsImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserDetailsService, IUserService {
    @Autowired
    private IUserRepository repository;

    public UserServiceImpl(IUserRepository repository) {
        this.repository = repository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) {
        User user=findByusername(username);
        return toUserDetails(user);
    }

    User findByusername(String username) {
        Optional<User> userFound = repository.findUserByusername(username);
        if (!userFound.isPresent()) {
            throw new UsernameNotFoundException("user with this Username not found "+username);
        }
        return userFound.get();
    }

    public UserDetails toUserDetails(User user) {
        ProspectDetailsImpl details = new ProspectDetailsImpl();
        details.setUsername(user.getUsername());
        details.setPassword(user.getPassword());
        Set<String> roles = user.getRoles();
        List<SimpleGrantedAuthority> authorities = roles.stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role.toUpperCase()))
                .collect(Collectors.toList());
        details.setAuthorities(authorities);
        return details;
    }
}
