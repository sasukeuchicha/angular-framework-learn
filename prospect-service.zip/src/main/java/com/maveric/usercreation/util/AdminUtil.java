package com.maveric.usercreation.util;

import com.maveric.usercreation.entities.Admin;
import com.maveric.usercreation.entities.User;
import com.maveric.usercreation.dtos.AdminDetails;
import org.springframework.stereotype.Component;

@Component
public class AdminUtil {
    public AdminDetails adminDetails(Admin admin) {
        User user = admin.getUser();
        AdminDetails desired = new AdminDetails();
        desired.setAdminId(admin.getId());
        desired.setRoles(user.getRoles());
        desired.setusername(user.getUsername());
        return desired;
    }

}
