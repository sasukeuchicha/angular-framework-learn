package com.maveric.usercreation.util;

import com.maveric.usercreation.dtos.ProspectDetails;
import org.springframework.stereotype.Component;

@Component
public class ProspectCache {
    private ProspectDetails prospectCache;
    public void addDetails(ProspectDetails prospectDetails){
        prospectCache = prospectDetails;
    }
    public long getId(){
        return prospectCache.getProspectId();
    }
    public String getusername(){
        return  prospectCache.getUsername();
    }
    public ProspectDetails getEntireDetails(){
        return prospectCache;
    }
    public void clearCache(){
        prospectCache = null;
    }
}
