package com.maveric.usercreation.util;

import com.maveric.usercreation.entities.Prospect;
import com.maveric.usercreation.entities.User;
import com.maveric.usercreation.dtos.ProspectDetails;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class ProspectUtil {
    public ProspectDetails prospectDetails(Prospect prospect) {
        User user = prospect.getUser();
        ProspectDetails prospectDetails = ProspectDetails.builder()
                .prospectId(prospect.getProspectId())
                .username(user.getUsername())
                .firstName(prospect.getFirstName())
                .lastName(prospect.getLastName())
                .mobileNumber(prospect.getMobileNumber())
                .build();
        return prospectDetails;
    }

    public List<ProspectDetails> toDetailsList(Collection<Prospect>prospects){
      List<ProspectDetails>list=  prospects.stream()
                .map(this::prospectDetails)
                .collect(Collectors.toList());
      return list;
    }


}
