package com.maveric.usercreation.controllers;

import com.maveric.usercreation.config.security.JwtAuthResponse;
import com.maveric.usercreation.dtos.AddProspect;
import com.maveric.usercreation.dtos.LoginRequest;
import com.maveric.usercreation.dtos.ProspectDetails;
import com.maveric.usercreation.exceptions.AnotherUserSignedInException;
import com.maveric.usercreation.exceptions.EmailAlreadyExistException;
import com.maveric.usercreation.exceptions.InvalidCredentialsException;
import com.maveric.usercreation.service.IAppService;
import com.maveric.usercreation.service.IProspectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/app/")

public class AppController {

    @Autowired
    private IAppService appService;
    @Autowired
    private IProspectService prospectService;

    @PostMapping("login")
    public ResponseEntity<JwtAuthResponse> login(@RequestBody LoginRequest requestDto) throws InvalidCredentialsException {
        return appService.login(requestDto);
    }
    @PostMapping("signup")
    public ResponseEntity<ProspectDetails> register(@RequestBody AddProspect requestData) throws AnotherUserSignedInException, EmailAlreadyExistException {
        ProspectDetails prospect = prospectService.register(requestData);
        return ResponseEntity.accepted().body(prospect);
    }
    /*
    @GetMapping("logout")
    public ResponseEntity<String> logout(){
        return ResponseEntity.ok("Logged out successfully");
    }
     */

}
