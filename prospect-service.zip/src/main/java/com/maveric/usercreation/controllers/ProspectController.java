package com.maveric.usercreation.controllers;

import com.maveric.usercreation.dtos.AddProspect;
import com.maveric.usercreation.dtos.ChangePassword;
import com.maveric.usercreation.dtos.ProspectDetails;
import com.maveric.usercreation.exceptions.ChangePasswordNotSameException;
import com.maveric.usercreation.exceptions.EmailNotFoundException;
import com.maveric.usercreation.exceptions.JWTAuthenticationException;
import com.maveric.usercreation.exceptions.ProspectIdNotFoundException;
import com.maveric.usercreation.service.IProspectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user/")
public class ProspectController {
    private IProspectService prospectService;
    @Autowired
    public ProspectController(IProspectService service){
        this.prospectService =service;
    }
    @PutMapping("update")
    public ResponseEntity<ProspectDetails> update(@RequestBody AddProspect requestDto, @RequestHeader("Authorization") String authHeader) throws EmailNotFoundException, JWTAuthenticationException, ProspectIdNotFoundException {
       ProspectDetails prospect = prospectService.update(requestDto, authHeader);
       return ResponseEntity.accepted().body(prospect);
    }
    @PutMapping("change-password")
    public ResponseEntity<ProspectDetails> changePassword(@RequestBody ChangePassword requestData, @RequestHeader("Authorization") String authHeader) throws EmailNotFoundException, JWTAuthenticationException, ChangePasswordNotSameException, ProspectIdNotFoundException {
        ProspectDetails prospect = prospectService.changePassword(requestData, authHeader);
        return ResponseEntity.accepted().body(prospect);
    }
    @GetMapping("get-details")
    public ResponseEntity<ProspectDetails> fetchCustomer(@RequestHeader("Authorization") String authHeader) throws EmailNotFoundException, JWTAuthenticationException, ProspectIdNotFoundException {
         ProspectDetails prospect = prospectService.getProspectDetails(authHeader);
         return ResponseEntity.ok(prospect);
    }
    @GetMapping("get-id")
    public ResponseEntity<Long> fetchProspectId(@RequestHeader("Authorization") String authHeader) throws EmailNotFoundException, JWTAuthenticationException, ProspectIdNotFoundException {
        long prospectId = prospectService.getCurrentProspectId(authHeader);
        return ResponseEntity.ok(prospectId);
    }
    @GetMapping("get-user")
    public ResponseEntity<ProspectDetails> getDetails(@RequestHeader("Authorization") String authHeader) throws EmailNotFoundException, JWTAuthenticationException, ProspectIdNotFoundException {
        ProspectDetails prospectDetails = prospectService.getProspectDetails(authHeader);
        return ResponseEntity.ok().body(prospectDetails);
    }
}
