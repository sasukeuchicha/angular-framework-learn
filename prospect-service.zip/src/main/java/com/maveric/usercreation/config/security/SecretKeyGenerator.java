package com.maveric.usercreation.config.security;

import lombok.SneakyThrows;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class SecretKeyGenerator {
    private static SecretKey generateKey() throws NoSuchAlgorithmException {
        // Initialize the KeyGenerator for HMAC-SHA512
        KeyGenerator keyGen = KeyGenerator.getInstance("HmacSHA512");

        // SecureRandom provides a cryptographically strong random number generator
        SecureRandom secureRandom = new SecureRandom();

        // Generate a random key
        keyGen.init(secureRandom);
        return keyGen.generateKey();
    }


    public static String generateSecretKey() throws Exception {
        try {
            SecretKey key = generateKey();
            byte[] keyBytes = key.getEncoded();

            // Printing the key in hexadecimal format
            StringBuilder hexKey = new StringBuilder();
            for (byte b : keyBytes) {
                hexKey.append(String.format("%02x", b));
            }
            return hexKey.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new Exception("Error creating a secret key. Server Failure. Restart application");
        }
    }
}
