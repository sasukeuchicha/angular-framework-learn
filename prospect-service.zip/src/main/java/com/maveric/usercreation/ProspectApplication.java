package com.maveric.usercreation;

import com.maveric.usercreation.dtos.AddAdmin;
import com.maveric.usercreation.service.IAdminService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class ProspectApplication {
    public static void main(String[] args) {
        ApplicationContext context=SpringApplication.run(ProspectApplication.class,args);
        IAdminService service=context.getBean(IAdminService.class);
        AddAdmin request=new AddAdmin("root","root");
        service.register(request);
    }
}